/**
 * 
 */
package secuencia.exception;

/**
 * @author angel
 *
 */
public class ErrorEndOfList extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6800199972340682628L;

	/**
	 * 
	 */
	public ErrorEndOfList() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public ErrorEndOfList(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public ErrorEndOfList(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ErrorEndOfList(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ErrorEndOfList(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
