/**
 * 
 */
package secuencia.exception;

/**
 * @author angel
 *
 */
public class ErrorBeginningOfList extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5956404126195026582L;

	/**
	 * 
	 */
	public ErrorBeginningOfList() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public ErrorBeginningOfList(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public ErrorBeginningOfList(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ErrorBeginningOfList(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ErrorBeginningOfList(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
